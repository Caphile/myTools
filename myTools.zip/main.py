import pandas as pd
import numpy as np
import chardet

class CSV:
    def detect_encoding(self, file_path):
        with open(file_path, 'rb') as f:
            result = chardet.detect(f.read())
        return result['encoding']

    def read(self, file_path):
        main_encoding = self.detect_encoding(file_path)
        main_encoding = 'euc-kr' if main_encoding is None else main_encoding
        try:
            df = pd.read_csv(file_path, encoding=main_encoding)
        except UnicodeDecodeError as e:
            df = pd.read_csv(file_path, encoding='cp949')
        return df

    def save(self, df, file_path):
        df.to_csv(file_path, index=False, encoding='utf8')

def combine(source_df, target_df):
    name_to_time = source_df.set_index('VOD_NAME')['VOD_TIME'].to_dict()
    target_df['VOD_TIME'] = target_df['VOD_NAME'].map(name_to_time)
    
    return target_df    

def target_make(union_df):
    # 데이터를 SETBX_ID와 CLICK_TIME 기준으로 정렬하고 VOD_NAME이 NaN인 행 제거
    union_df = union_df.dropna(subset=['VOD_NAME']).sort_values(by=['SETBX_ID', 'CLICK_TIME'])

    union_df[['YEAR', 'MONTH', 'DAY', 'HOUR', 'MIN']] = (
        union_df['CLICK_TIME']
        .str.extract(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):')
    )
    union_df = union_df.drop(columns=['CLICK_TIME'])

    # 중복 행 제거 (SETBX_ID, VOD_NAME, YEAR, MONTH, DAY, HOUR, MIN, VIEW_TYPE 기준, 마지막 값 유지)
    cln_df = union_df.drop_duplicates(subset=['SETBX_ID', 'VOD_NAME', 'YEAR', 'MONTH', 'DAY', 'HOUR', 'MIN', 'VIEW_TYPE'], keep='last')
    
    # view 열 초기화
    cln_df['view'] = np.nan

    def assign_view(group):
        for i in range(len(group) - 1):
            if group.iloc[i]['VIEW_TYPE'] == 'content' and group.iloc[i + 1]['VIEW_TYPE'] == 'vod':
                group.at[group.index[i], 'view'] = 1
                group.at[group.index[i + 1], 'view'] = 5
        return group

    # 그룹별로 assign_view 함수 적용
    cln_df = cln_df.groupby(['SETBX_ID', 'VOD_NAME', 'DAY', 'HOUR'], group_keys=False).apply(assign_view)
    
    # view 값 채우기 (VIEW_TYPE가 vod이면 5, VIEW_TYPE가 content이고 view가 NaN이면 0)
    cln_df.loc[cln_df['VIEW_TYPE'] == 'vod', 'view'] = 5
    cln_df.loc[(cln_df['view'].isna()) & (cln_df['VIEW_TYPE'] == 'content'), 'view'] = 0

    return cln_df

def weight_make(main_df):
    # view 0값인 레코드 삭제
    main_df = main_df[main_df['view'] != 0]

    # time_rate 생성
    def convert_to_seconds(time_str):
        if pd.isna(time_str):
            return None
        HOURs, MINutes = map(int, time_str.split(':'))
        return HOURs * 3600 + MINutes * 60

    main_df['VOD_TIME_S'] = main_df['VOD_TIME'].apply(convert_to_seconds)
    main_df['time_rate'] = main_df.apply(lambda row: row['WATCH_TIME'] / row['VOD_TIME_S'] if row['WATCH_TIME'] is not None and row['VOD_TIME_S'] != 0 else None, axis=1)

    # click_rate 생성
    main_df['click_rate'] = None

    for setbx_id, group in main_df.groupby('SETBX_ID'):
        total_vod_count = group[group['VIEW_TYPE'] == 'vod']['VOD_NAME'].value_counts()

        for idx, row in group.iterrows():
            if row['VIEW_TYPE'] == 'vod':
                vod_name = row['VOD_NAME']
                if vod_name in total_vod_count and total_vod_count.sum() != 0:  # Avoid division by zero
                    main_df.at[idx, 'click_rate'] = 1.0 * total_vod_count[vod_name] / total_vod_count.sum()

    # 조화평균
    def harmonic_mean(series):
        series = series.dropna()
        if len(series) == 0:
            return np.nan
        return len(series) / np.sum(1.0 / series)

    main_df['temp'] = main_df['click_rate'] * main_df['time_rate']

    harm_mean_df = main_df[main_df['VIEW_TYPE'] == 'vod'].groupby(['SETBX_ID', 'VOD_NAME'])['temp'].apply(harmonic_mean).reset_index()
    harm_mean_df.columns = ['SETBX_ID', 'VOD_NAME', 'NEW_TARGET']

    main_df = pd.merge(main_df, harm_mean_df, on=['SETBX_ID', 'VOD_NAME'], how='left')

    filtered_df = main_df[main_df['VIEW_TYPE'] == 'content'][['SETBX_ID', 'VOD_NAME', 'view', 'NEW_TARGET']].copy()
    filtered_df.drop_duplicates(subset=['SETBX_ID', 'VOD_NAME', 'view', 'NEW_TARGET'], inplace=True)

    return filtered_df

def main():

    csv = CSV()
    
    source_file_path = 'db_mongo.vod.csv'
    target_file_path = 'for_gayoung.csv'
    
    df = combine(csv.read(source_file_path), csv.read(target_file_path))
    df = target_make(df)
    df = weight_make(df)

    updated_file_path = r'userlist.csv'
    csv.save(df, updated_file_path)

if __name__ == '__main__':
    main()